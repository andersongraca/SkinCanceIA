# Google DermAssist: pesquisa e comparação com o protótipo SkinCancerCADDermoIA

## Escopo e conclusão

Esta nota trata **somente do Google DermAssist**. A comparação com o **SkinCancerCADDermoIA** usa apenas os componentes informados para o protótipo: dermatoscopia, CNN ResNet-50, Vision Transformer (ViT), modelo híbrido, ensemble ponderado, triagem fora da distribuição (*out-of-distribution*, OOD), incerteza e explicabilidade por IA (XAI). Nenhuma métrica, aprovação regulatória ou capacidade clínica foi atribuída ao protótipo sem fonte.

A conclusão principal é que DermAssist foi apresentado como uma ferramenta web de assistência e informação dermatológica ao consumidor, baseada em fotografias feitas com a câmera do telefone e respostas a perguntas. O produto não foi destinado a fornecer diagnóstico ou substituir aconselhamento médico. A página oficial atual do Google informa que o recurso relacionado **não está mais em desenvolvimento**; portanto, não deve ser descrito como um produto clínico atual ou disponível. [1]

É importante separar três objetos que às vezes são tratados como se fossem um só: **(a)** o produto DermAssist anunciado pelo Google em 2021; **(b)** o modelo de pesquisa de diagnóstico diferencial publicado em *Nature Medicine* e usado como base científica relacionada; e **(c)** um estudo separado de utilidade de uma ferramenta para profissionais não especialistas que incorporou esse modelo. A publicação primária fornece evidência clínica retrospectiva para um sistema de pesquisa, mas não divulga todos os detalhes do produto DermAssist nem prova que a versão comercial usou exatamente o mesmo modelo. [2] [3] [4]

## Identificação, modalidade, finalidade e estado

| Campo | Google DermAssist |
|---|---|
| Categoria | Ferramenta web de assistência dermatológica e recuperação de informação para consumidores; foi descrita pelo Google como dispositivo médico Classe I com marcação CE na União Europeia. |
| Modalidade de entrada | Três fotografias de uma preocupação na pele, no cabelo ou na unha, capturadas com a câmera do telefone e em ângulos diferentes, além de respostas sobre tipo de pele, duração do problema e sintomas. A descrição oficial não menciona dermatoscopia ou hardware especializado. [1] |
| Uso pretendido | Ajudar a pessoa a entender o que pode estar ocorrendo e pesquisar condições possíveis. O Google declarou expressamente que a ferramenta não fornece diagnóstico e não substitui aconselhamento médico, exame presencial ou exames adicionais, como biópsia. [1] |
| Saídas descritas | Lista de possíveis condições correspondentes entre 288 condições; para cada item, informação revisada por dermatologistas, respostas a perguntas frequentes e imagens semelhantes encontradas na web. [1] |
| Estado atual | O anúncio de 2021 descrevia um piloto planejado, inicialmente não disponível nos Estados Unidos. A página atual de produtos do Google diz que a função de busca visual relacionada não é o DermAssist e que o DermAssist **não está mais em desenvolvimento**. Não foi encontrada, nas fontes oficiais consultadas, uma data de encerramento, uma explicação do motivo ou uma implantação assistencial atual. [1] [5] |
| Regulação declarada | O Google declarou marcação CE como dispositivo médico Classe I na União Europeia. Também declarou que a ferramenta não havia sido avaliada pela FDA quanto à segurança ou eficácia e não estava disponível nos Estados Unidos. Marcação CE Classe I não equivale a validação de um rastreador autônomo de câncer nem a demonstração de benefício clínico em população não selecionada. [1] |

## O que é conhecido sobre a abordagem técnica

A arquitetura do **modelo diagnóstico utilizado no produto DermAssist não foi divulgada** nas fontes oficiais consultadas. Não há especificação pública suficiente para afirmar que o produto usa ResNet-50, Vision Transformer, um híbrido CNN–ViT, ensemble ponderado, triagem OOD ou incerteza calibrada. Também não foram divulgados os pesos, a taxonomia completa de 288 condições, os limiares, a política de abstinência, o procedimento de calibração ou os detalhes de pré-processamento do classificador final.

O Google publicou detalhes de um componente diferente: o **controle de qualidade da imagem no dispositivo**. Esse componente usava MobileNetV2 como extrator, múltiplas cabeças binárias para problemas como desfoque e iluminação inadequada, mais de 30 mil imagens para treinamento e execução via TensorFlow.js. Ele orientava o usuário a refazer a captura antes do envio. Essa publicação não descreve a arquitetura do classificador de doenças e não deve ser usada para concluir que o DermAssist diagnóstico era MobileNetV2. [6]

A evidência técnica primária relacionada vem de Liu et al. O sistema de pesquisa recebia uma ou mais imagens clínicas e até 45 tipos de metadados de história, como idade, sexo e sintomas. As imagens passavam por uma arquitetura Inception-v4; os metadados eram transformados em características e combinados na camada de classificação. O sistema produzia uma lista diferencial ordenada, em vez de uma única classe. A versão publicada distinguiu 26 condições comuns, que representavam aproximadamente 80% dos casos de atenção primária, e forneceu uma previsão secundária cobrindo 419 condições. [2] [3] [4]

Esse sistema de pesquisa **não é equivalente, por documentação pública, ao SkinCancerCADDermoIA**. Ele não foi descrito como ResNet-50, ViT, modelo híbrido ou ensemble ponderado. Além disso, as fontes oficiais do produto mencionam 288 condições, enquanto o artigo primário menciona 26 classes principais e uma saída secundária de 419 condições. Essa diferença pode refletir escopo, versão ou taxonomia diferentes; não é correto misturar os números como se fossem a mesma lista ou afirmar que o produto implantado reproduzia exatamente o sistema publicado.

## Saídas, XAI e segurança da decisão

A saída de produto documentada era uma **lista de condições possíveis acompanhada de conteúdo informativo**, não uma decisão binária de câncer, uma probabilidade clínica calibrada ou uma recomendação autônoma de tratamento. O Google não publicou uma descrição de uma saída OOD, de um intervalo de incerteza ou de uma regra formal de encaminhamento para cada nível de confiança.

As fontes oficiais consultadas também não descrevem uma explicação XAI individual exibida ao consumidor, como mapa de saliência, mapa de atenção, exemplo por similaridade validado ou justificativa textual gerada a partir da imagem. A página do Google informa que as imagens semelhantes na web são parte do conteúdo mostrado ao usuário, mas isso não constitui explicação causal ou garantia de que a decisão usou características clinicamente corretas. [1]

No estudo primário relacionado, os autores fizeram análise qualitativa por técnicas de saliência e relataram que o sistema tendia a destacar a anormalidade em vez da cor da pele. Essa análise é uma ferramenta de inspeção do modelo de pesquisa e não prova que o produto DermAssist fornecia XAI na interface, nem que a explicação era fiel, estável ou clinicamente suficiente. [3] Em uma ferramenta distinta para profissionais, a interface mostrou medida de confiança, exemplos canônicos e aviso de dados limitados; o estudo não autoriza atribuir esses elementos ao produto consumidor DermAssist. [4]

Portanto, para DermAssist, permanece **não divulgado** se havia:

- detecção explícita de entradas OOD ou inválidas além do controle de qualidade de imagem;
- abstinência ou encaminhamento automático quando a confiança era baixa;
- calibração probabilística, estimativa de incerteza epistêmica ou aleatória;
- XAI na interface final e método usado para produzi-la;
- avaliação de fidelidade, estabilidade e utilidade clínica das explicações.

## Validação e força da evidência

A alegação oficial do Google é que o modelo que alimentava a ferramenta “passou por validação clínica” e que o produto recebeu marcação CE Classe I. A publicação oficial não apresenta, para a versão do produto com 288 condições, protocolo completo, conjunto independente, métricas por condição, intervalos de confiança, desempenho por tom de pele, limiar operacional ou avaliação prospectiva. Assim, essa é uma **alegação institucional de validação**, não uma métrica clínica reproduzível por si só. Ela não deve ser confundida com evidência de segurança ou eficácia para rastrear câncer. [1]

A publicação primária de Liu et al. é a evidência revisada por pares mais direta para o sistema de pesquisa relacionado. Ela usou casos desidentificados de teledermatologia com fotografias clínicas e dados clínicos. Na comparação em 963 casos, um painel rotativo de três dermatologistas certificados definiu o padrão de referência; a acurácia *top-1* foi 0,66 para o sistema, 0,63 para seis dermatologistas, 0,44 para seis médicos de atenção primária e 0,40 para seis enfermeiros especialistas. O resultado demonstrou desempenho comparativo retrospectivo no conjunto estudado. [2]

A descrição institucional do Google sobre o mesmo trabalho informa uma versão de desenvolvimento e validação com 17.777 casos, 3.756 casos na validação principal e 963 casos em um subconjunto comparativo; relata acurácia *top-1* de 0,71 e *top-3* de 0,93 na validação principal e *top-3* de 0,90 no subconjunto comparativo. O artigo final em *Nature Medicine* resume números diferentes, incluindo 16.114 casos e 963 casos comparativos. Esses números devem ser citados conforme a fonte e a versão, sem somá-los ou tratá-los como uma única coorte. [2] [3]

Um estudo de utilidade publicado em *JAMA Network Open* avaliou uma ferramenta web baseada no algoritmo de Liu et al. em 1.048 casos retrospectivos que representavam 120 condições. Vinte médicos de atenção primária e 20 enfermeiros especialistas revisaram casos com ou sem assistência. A concordância com o diagnóstico do painel de dermatologistas aumentou de 48% para 58% entre médicos e de 46% para 58% entre enfermeiros. O estudo apoia a hipótese de que assistência por IA pode ajudar profissionais não especialistas, mas não é um estudo prospectivo do produto consumidor DermAssist e não demonstra desfechos de pacientes. [4]

A evidência, portanto, sustenta três afirmações limitadas: o sistema de pesquisa pôde classificar casos de teledermatologia retrospectivos; a assistência baseada nesse sistema melhorou a concordância de profissionais em um experimento retrospectivo; e o Google anunciou uma versão de produto com marcação CE. Ela **não** sustenta, sem dados adicionais, que DermAssist reduzia mortalidade, identificava câncer com segurança em casa, diminuía biópsias desnecessárias, funcionava em todas as tonalidades de pele ou mantinha desempenho após o encerramento do desenvolvimento.

## Limitações e itens proprietários ou não divulgados

1. **Produto diferente da publicação primária.** O Google não publicou uma correspondência verificável entre a versão de produto com 288 condições e o sistema de pesquisa de 26/419 condições. A arquitetura, os pesos e a versão exata permanecem não divulgados.
2. **Modalidade sem dermatoscopia.** DermAssist foi descrito com fotografias de telefone da pele, do cabelo ou da unha. Não há evidência oficial consultada de entrada dermatoscópica. O desempenho do produto não pode ser comparado diretamente ao de um protótipo treinado em dermatoscopia sem um estudo que controle a modalidade.
3. **Não diagnóstico.** O propósito declarado era informar e sugerir condições possíveis. Exame físico, história completa, testes e biópsia podem ser necessários; a própria fonte oficial rejeita a interpretação como diagnóstico ou substituto de orientação médica. [1]
4. **Validação do produto não reproduzível nas fontes públicas consultadas.** “Passou por validação clínica” não vem acompanhado, na publicação do produto, de tamanho de amostra, padrão de referência, métricas, intervalos, prevalência, critérios de exclusão ou protocolo de validação independente. [1]
5. **Generalização e tom de pele.** No sistema de pesquisa relacionado, os autores relataram desempenho semelhante nos tipos Fitzpatrick II–IV, mas tipos menos representados não permitiam análise equivalente. O estudo de utilidade informou sub-representação dos tipos I e V e ausência do tipo VI em seu conjunto. Uma análise independente destacou que apenas 3,5% do conjunto de desenvolvimento tinha tipos V e VI e que a sensibilidade para crescimentos malignos no artigo original foi menor para a IA do que para dermatologistas; essa é uma crítica de terceiros ao sistema publicado, não uma métrica comprovada da versão de produto. [3] [4] [7]
6. **Câncer não é o escopo demonstrado do produto.** A ferramenta foi apresentada para questões comuns de pele, cabelo e unhas. Não se deve converter uma lista de condições possíveis em uma promessa de rastreamento de câncer. O estudo primário relacionado reconheceu limitações para câncer, inclusive rótulos não necessariamente confirmados por biópsia e menor frequência de malignidade.
7. **Cenário retrospectivo e teledermatológico.** A validação principal não mostrou impacto prospectivo em fluxo assistencial, tempo até diagnóstico, adesão, segurança longitudinal ou desfecho de paciente. O estudo com profissionais também usou casos retrospectivos.
8. **Dados restritos e reprodutibilidade parcial.** Os dados de teledermatologia do artigo primário não eram públicos por restrições de compartilhamento. O produto, seu conjunto de dados, pesos e código do classificador não foram disponibilizados nas fontes consultadas. [2]
9. **Qualidade da imagem não é incerteza clínica.** O controle de desfoque e iluminação ajuda a captura, mas não detecta necessariamente uma entrada clinicamente fora da distribuição. Não há documentação pública de que essa função implementava OOD ou abstinência diagnóstica.
10. **Estado atual e regulação.** A página atual do Google diz que o DermAssist não está mais em desenvolvimento. A marcação CE declarada e a ausência de avaliação FDA não autorizam inferências sobre disponibilidade atual, eficácia nos Estados Unidos ou desempenho de versões futuras. [5]

## Comparação delimitada com o SkinCancerCADDermoIA

| Dimensão | Google DermAssist e evidência relacionada | SkinCancerCADDermoIA, conforme a descrição recebida | Ponto de comparação |
|---|---|---|---|
| Modalidade | Fotografias clínicas feitas com câmera de telefone; três ângulos e questionário. Não há dermatoscopia documentada. [1] | Dermatoscopia. | São entradas diferentes. Não se deve transportar métricas de fotografia clínica para dermatoscopia nem o contrário sem teste pareado. |
| Finalidade | Informação e lista de possíveis condições; não diagnóstico nem substituto de médico. [1] | O pedido informa um protótipo de análise/triagem de câncer de pele, mas não fornece uma declaração regulatória ou uma indicação clínica formal. | A finalidade do protótipo ainda precisa ser escrita como uso pretendido verificável, incluindo usuário, população, ação e limites. |
| Modelo conhecido | Produto: arquitetura final não divulgada. Pesquisa relacionada: Inception-v4 com múltiplas imagens e metadados; não há base pública para chamá-lo de ResNet-50, ViT, híbrido ou ensemble. [3] | CNN ResNet-50, ViT, modelo híbrido e ensemble ponderado, conforme descrição do protótipo. | O protótipo documenta maior diversidade arquitetural, mas isso não demonstra superioridade, calibração ou benefício clínico. |
| Saída | Lista ordenada ou conjunto de condições possíveis, conteúdo revisado por dermatologistas, perguntas frequentes e imagens semelhantes. O formato de probabilidade e os limiares não são públicos. [1] [3] | O formato da saída, classes, probabilidades e política de decisão não foram informados. | Ambos precisam de especificação de saída para permitir auditoria; não se deve tratar uma pontuação de classe como risco individual sem calibração. |
| OOD/abstinência | Não divulgados para o classificador do produto. O controle de qualidade de imagem é um componente separado. | Triagem OOD informada. | É uma diferença potencialmente importante de segurança. Deve ser comprovada com conjuntos OOD, entradas inválidas, limiares pré-especificados, cobertura e risco após abstinência. |
| Incerteza | Não divulgada como método calibrado no DermAssist. A ferramenta de profissionais relacionada tinha medida de confiança e aviso de dados limitados, mas isso não prova que eram saídas do produto consumidor. [4] | Incerteza informada como componente, sem método, calibração ou resultados fornecidos. | É necessário distinguir confiança de incerteza estatística e demonstrar calibração, cobertura, risco e comportamento por subgrupo. |
| XAI | Nenhuma XAI de interface foi documentada para o produto. O trabalho relacionado mostrou saliência como análise qualitativa. [3] | XAI informada, mas sem método ou estudo de fidelidade/estabilidade. | Comparar métodos, e não apenas imagens, incluindo fidelidade, estabilidade, sensibilidade a artefatos e utilidade para o usuário. |
| Validação | Artigo primário relacionado: 963 casos comparativos, *top-1* 0,66 para o DLS contra 0,63 para dermatologistas; estudo JAMA retrospectivo mostrou aumento de concordância com assistência. A versão de produto só tem a alegação oficial de “validação clínica” sem protocolo público equivalente. [1] [2] [4] | Nenhuma coorte, métrica, referência, intervalo de confiança, comparador ou estudo clínico foi fornecido. | Não é válido afirmar que o protótipo tem desempenho de dermatologista ou que supera DermAssist. É necessário um teste independente e, idealmente, prospectivo, com protocolo comum. |
| Limitações de dados | Casos de teledermatologia e subgrupos de tom de pele com representação desigual; dados primários não públicos. [2] [4] [7] | Dados, partições por paciente/lesão, origem dos rótulos e cobertura de tons de pele não informados. | Documentar separação por paciente e lesão, confirmação histopatológica quando relevante, prevalência, subgrupos, shift de câmera e modalidade. |
| Regulação e estado | CE Classe I declarado; não avaliado pela FDA; página atual do Google informa que não está mais em desenvolvimento. [1] [5] | Protótipo, conforme o escopo recebido; nenhuma aprovação ou implantação foi informada. | O estado experimental deve ser mantido explícito. Marca, protótipo e artigo não equivalem a autorização para uso clínico. |

## Interpretação correta das alegações

A linguagem comercial e institucional do Google deve ser lida em camadas. “Conhece 288 condições”, “passou por validação clínica” e “recebeu marcação CE” descrevem o produto ou a posição institucional do fabricante; não fornecem, por si sós, métricas auditáveis de cada condição, desempenho em prevalência real, segurança para melanoma, calibração, equidade entre tons de pele ou benefício clínico. [1]

A evidência científica revisada por pares é mais específica: o DLS relacionado teve desempenho comparativo em casos retrospectivos de teledermatologia e uma ferramenta para profissionais melhorou a concordância diagnóstica em um experimento retrospectivo. Esses resultados são relevantes para a hipótese de assistência, mas não autorizam afirmar que o produto DermAssist atual — que o Google hoje declara não estar em desenvolvimento — é um dispositivo autônomo de detecção de câncer ou que qualquer versão futura preservaria essas métricas. [2] [4] [5]

Para o SkinCancerCADDermoIA, ResNet-50, ViT, híbrido, ensemble ponderado, OOD, incerteza e XAI devem ser tratados como **especificação de protótipo** até que sejam acompanhados por dados e protocolo. Permanecem não divulgados nesta comparação: conjuntos de treino, validação e teste; origem e confirmação dos rótulos; separação por paciente e lesão; desempenho por classe, tom de pele e dispositivo; calibração; limiar OOD; política de abstinência; método de incerteza; método e avaliação de XAI; comparação com dermatologistas; avaliação prospectiva; aprovação regulatória; e status de implantação.

## Referências

[1]: https://blog.google/innovation-and-ai/technology/health/ai-dermatology-preview-io-2021/ "Google — Using AI to help find answers to common skin conditions"

[2]: https://www.nature.com/articles/s41591-020-0842-3 "Liu et al. — A deep learning system for differential diagnosis of skin diseases, Nature Medicine (2020)"

[3]: https://research.google/blog/using-deep-learning-to-inform-differential-diagnoses-of-skin-diseases/ "Google Research — Using Deep Learning to Inform Differential Diagnoses of Skin Diseases"

[4]: https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2779250 "Liu et al. — Association of Physician Diagnostic Accuracy With Use of an AI-Based Decision Support System, JAMA Network Open (2021)"

[5]: https://health.google/products/ "Google Health — Google Products"

[6]: https://blog.tensorflow.org/2021/10/how-DermAssist-uses-TensorFlowJS.html "Google TensorFlow Blog — How DermAssist uses TensorFlow.js for on-device image quality checks"

[7]: https://onlinelibrary.wiley.com/doi/full/10.1002/jvc2.246 "O’Hagan and Ungar — Considering the practical implications of Google’s consumer-facing deep learning skin evaluation software DermAssist"

**Nota de escopo:** foram consultadas fontes oficiais do Google e publicações científicas primárias. A publicação de opinião independente [7] foi usada somente para registrar críticas e limitações relatadas por terceiros; não foi tratada como validação clínica. Alegações comerciais não foram convertidas em evidência de eficácia ou segurança.

---

*Autor padrão: Manus AI.*
