# SkinVision: nota técnica e comparação com o SkinCancerCADDermoIA

**Escopo.** Esta nota examina somente o SkinVision e o compara com o protótipo **SkinCancerCADDermoIA**, conforme a descrição recebida: dermatoscopia, CNN ResNet-50, Vision Transformer, modelo híbrido, ensemble ponderado, triagem fora da distribuição (OOD), incerteza e explicabilidade (XAI). A separação entre **alegação da empresa**, **documentação regulatória** e **evidência clínica publicada** é deliberada.

## Conclusão executiva

O SkinVision é um dispositivo médico móvel de venda direta ao consumidor. Sua entrada é uma fotografia macroscópica de uma lesão cutânea obtida pela câmera de um smartphone; ele não usa, na documentação consultada, dermatoscopia como modalidade de entrada. Seu uso pretendido é produzir uma **indicação de risco**, não diagnosticar câncer: em termos operacionais, recomenda monitorar a lesão ou procurar um profissional de saúde. A documentação oficial vigente descreve apenas um algoritmo estatístico baseado em inteligência artificial, treinado com fotografias anotadas por dermatologistas certificados. Uma publicação primária descreve uma versão como CNN RD-174, mas a arquitetura, os pesos, o conjunto de treinamento, o limiar de decisão, a calibração, o mecanismo de atualização e os critérios de rejeição não são divulgados publicamente.

A evidência independente é heterogênea e inferior às cifras promocionais quando se consideram cenários prospectivos e lesões realmente suspeitas. Em um estudo multicêntrico prospectivo de 2022, a sensibilidade foi 86,9% e a especificidade 70,4%; em um estudo prospectivo independente publicado em 2026, a sensibilidade foi 82,5% e a especificidade 76,8% entre imagens capturadas com sucesso. Nesse último estudo, 16,6% das lesões não puderam ser fotografadas pelo aplicativo mesmo em condições ideais, e a taxa de sucesso caiu para 28,9% quando a própria pessoa tentou capturar a imagem. Outro estudo prospectivo, focado em lesões pigmentadas de alto risco, encontrou sensibilidade de 41,3–83,3% e especificidade de 60,0–82,9%, conforme o padrão de referência, além de sobre-detecção que poderia gerar excisões desnecessárias.

Portanto, o SkinVision é uma referência de **triagem consumerizada com validação clínica e fluxo de segurança**, mas não uma referência arquitetural transparente para o SkinCancerCADDermoIA. O protótipo proposto é mais explícito quanto à arquitetura, à combinação de modelos, à detecção OOD, à incerteza e à XAI. Ainda assim, a vantagem do protótipo só será uma vantagem clínica depois de validação prospectiva externa, com padrão histopatológico quando indicado, controle de captura, diferentes dispositivos, tons de pele e comparação entre modalidade dermatoscópica e fotografia macroscópica.

## O que o produto é e para que serve

A instrução de uso vigente identifica o SkinVision como um aplicativo médico móvel **somente software**, de venda direta ao consumidor, destinado a leigos adultos em dispositivos móveis de consumo. O módulo de avaliação recebe a fotografia da lesão feita no próprio aplicativo e devolve uma indicação imediata de risco para os tipos mais comuns de câncer de pele. A saída orienta o usuário a continuar monitorando ou a procurar um profissional de saúde. A instrução afirma expressamente que o serviço **não diagnostica câncer de pele**, não oferece outro diagnóstico e não substitui o profissional de saúde.[1]

O aplicativo também permite registrar lesões em um mapa corporal, definir lembretes, guardar imagens e gerar um relatório. A documentação atual ressalva que o algoritmo não analisa a mudança entre fotografias sucessivas e não sobrepõe imagens para comparação longitudinal.[1] A instrução de uso orienta, para um resultado de alto risco, consulta médica preferencialmente em até quatro semanas; para baixo risco sem sintomas, recomenda novo monitoramento em três meses. Há ainda um estado de verificação de qualidade quando o algoritmo entende que precisa de uma checagem adicional.[1]

A página oficial consultada informa que o produto não está disponível nos Estados Unidos e que o lançamento depende da autorização regulatória aplicável. Isso não deve ser interpretado como autorização da FDA.[2] Em comunicado de 2025, a empresa declarou certificação **CE sob o EU MDR, classe IIa**.[3] Essa certificação é um estado regulatório e uma alegação de conformidade do dispositivo; por si só, não equivale a uma estimativa independente de desempenho no uso populacional, nem valida a arquitetura interna.

## Modalidade de entrada e restrições de aquisição

A modalidade documentada é uma fotografia **macroscópica de close-up**, feita pela câmera traseira do smartphone. A instrução requer câmera com foco automático, resolução mínima de vídeo de 720p, lanterna e conexão ativa à internet. O aplicativo verifica foco, detecção da lesão e nitidez antes de aceitar a fotografia.[1] O estudo de Jahn et al. especifica que o SkinVision avaliou apenas imagens macroscópicas próximas, enquanto os sistemas de comparação baseados em CNN 2D e 3D usaram imagens dermatoscópicas.[4]

A instrução de uso lista situações em que não se recomenda fotografar: baixo contraste entre lesão e pele, fototipos IV–VI por limitações da câmera, agrupamento de lesões ou irritação, pele não íntegra, região subungueal, cicatriz, matéria estranha, pelos abundantes, mucosas e dobras cutâneas, entre outras.[1] Essa lista é importante para a comparação: o SkinVision não deve ser tratado como equivalente a um sistema baseado em dermatoscopia. O seu modelo precisa operar com iluminação, foco, cor, pelos, localização anatômica e qualidade de captura variáveis no mundo real.

## Abordagem técnica conhecida e o que permanece proprietário

A documentação oficial atual informa que as recomendações são baseadas em um algoritmo de IA tratado como modelo estatístico, treinado em uma coleção extensa de fotos anotadas por dermatologistas certificados. Para imagens de maior risco, a empresa descreve uma etapa de controle de qualidade que inclui avaliação adicional por um painel de dermatologistas.[1] O controle humano é um mecanismo de segurança e de operação do serviço; não é, por si só, uma explicação do raciocínio visual do modelo.

Na validação prospectiva multicêntrica de Sangers et al., a versão estudada foi identificada como **CNN RD-174**. A CNN classificava a lesão como baixo ou alto risco em até 30 segundos; lesões pré-malignas e malignas foram treinadas como alto risco. O usuário era orientado a monitorar uma lesão de baixo risco ou consultar um médico para uma de alto risco.[5] O artigo não descreve ResNet-50, Vision Transformer, arquitetura híbrida, ensemble ponderado, detector OOD, estimativa de incerteza ou mapas de saliência.

A revisão de Carvalho et al. registra a evolução histórica do produto: versões iniciais usavam análise fractal baseada em regras; versões posteriores passaram a usar aprendizado de máquina e, em 2018, a empresa relatava um conjunto de mais de 130.000 imagens classificadas por dermatologistas a partir de sua base de usuários.[6] Isso é histórico e não deve ser usado para atribuir a mesma arquitetura ao produto atual. Não há fonte pública consultada que permita afirmar que o SkinVision atual usa ResNet-50, ViT, um híbrido, um ensemble ou qualquer desses componentes.

Assim, os seguintes elementos devem ser classificados como **não divulgados publicamente ou proprietários**: arquitetura detalhada e backbone; pré-processamento e normalização; conjunto de treinamento e sua composição por fototipo, dispositivo e localização; política de atualização; limiares e calibração; pesos de eventual ensemble; detecção e tratamento de entradas OOD; escore de incerteza; e qualquer explicação visual ou textual derivada dos atributos da imagem.

## Saídas e explicabilidade

A saída clínica principal é uma indicação de risco, em termos binários ou operacionalmente equivalentes: baixo risco com monitoramento, alto risco com recomendação de consulta e, quando necessário, verificação de qualidade. A instrução também incorpora sintomas informados pelo usuário, como coceira, sangramento, mudança ou infecção, à orientação subsequente; ela esclarece que o perfil de risco pessoal e fatores ambientais são recursos informativos e não alteram o resultado do algoritmo.[1]

Não encontrei, nas fontes oficiais e publicações primárias lidas, uma explicação XAI do tipo mapa de saliência, Grad-CAM, atenção visual, superpixels, características clínicas extraídas ou justificativa auditável por caso. O produto expõe uma recomendação de risco e instruções de encaminhamento. A revisão por dermatologistas em casos de risco e a verificação de qualidade são camadas de controle, não XAI algorítmica. Também não encontrei divulgação de um intervalo de confiança por caso, probabilidade calibrada, score de incerteza ou decisão explícita de rejeitar uma entrada OOD. A categoria “quality check needed” indica uma falha ou necessidade operacional de qualidade, mas não foi apresentada como estimativa probabilística de incerteza epistêmica ou aleatória.

## Validação clínica: resultados primários e qualificadores

### Estudo prospectivo multicêntrico de Sangers et al. (2022)

Sangers et al. conduziram um estudo prospectivo multicêntrico em dois ambulatórios de dermatologia dos Países Baixos, de janeiro a agosto de 2020. Foram incluídas 785 lesões de 372 adultos, sendo 418 lesões suspeitas e 367 controles benignos. O resultado do aplicativo foi comparado à histopatologia quando disponível ou ao diagnóstico clínico dermatológico. O desempenho global foi **sensibilidade de 86,9%** (IC95% 82,3–90,7) e **especificidade de 70,4%** (IC95% 66,2–74,3).[5]

O desempenho variou com a plataforma: a sensibilidade foi 91,0% em iOS e 83,0% em Android. A especificidade foi 80,1% nos controles benignos, mas 45,5% nas lesões suspeitas, que são mais difíceis e mais próximas do cenário real de encaminhamento. As imagens foram feitas por pesquisadores treinados em ambiente ambulatorial, não por usuários em casa; imagens que não puderam ser capturadas com sucesso foram excluídas da análise principal. Mais de 80% dos participantes tinham fototipo Fitzpatrick I ou II, e apenas 12 melanomas foram incluídos. Esses pontos limitam a extrapolação para uso doméstico, população geral, dispositivos de menor qualidade e pele mais escura.[7]

O estudo recebeu uma bolsa de pesquisa irrestrita da SkinVision. A empresa declarou não ter participado do desenho, coleta, análise, interpretação ou redação; contudo, alguns autores tinham participação no conselho científico ou equity. Esse vínculo não invalida os resultados, mas deve acompanhar a leitura da estimativa.[7]

### Estudo prospectivo independente de Kips et al. (publicado em 2026)

Kips et al. avaliaram o aplicativo em um estudo prospectivo independente, entre fevereiro de 2021 e junho de 2023, com 1.458 participantes e 1.904 lesões de preocupação clínica. Havia 185 cânceres, incluindo 32 melanomas. A captura falhou em **317 de 1.904 lesões (16,6%)**, mesmo em condições ideais. Nas imagens capturadas com sucesso, a CNN apresentou **sensibilidade de 82,5%** e **especificidade de 76,8%**.[8]

Em uma parte do serviço, a revisão por teledermatologia combinada à CNN aumentou a especificidade para 86,8%, mas reduziu a sensibilidade para 75,3%. O estudo encontrou desempenho diferente conforme o smartphone e baixa taxa de sucesso quando o próprio usuário fazia a captura: 28,9% no subestudo de captura pelo usuário. A publicação, portanto, é especialmente relevante para separar desempenho condicional à imagem aceitável de desempenho do fluxo completo de uso. Ela também demonstra que uma recomendação de sensibilidade ou especificidade não resume o risco de falha na etapa anterior de aquisição.[8]

### Estudo prospectivo de Jahn et al. (2022): lesões pigmentadas e sobre-detecção

Jahn et al. estudaram 1.204 lesões pigmentadas em 114 pacientes de alto risco em um centro universitário suíço. A versão do aplicativo era a 6.8.1. Os resultados foram comparados com histologia ou, quando não disponível, com uma combinação de avaliações dermatológicas e sistemas 2D/3D de fotografia corporal total. A sensibilidade variou de **41,3% a 83,3%**, a especificidade de **60,0% a 82,9%** e a área sob a curva de 0,62 a 0,72, conforme o padrão de referência.[4]

O aplicativo classificou significativamente mais lesões como de alto risco que os dermatologistas. Os autores alertaram que a sobre-detecção poderia levar a um número clinicamente prejudicial de excisões desnecessárias. A confiança no aplicativo foi baixa: 36% dos pacientes de alto risco sem melanoma prévio, 49% dos pacientes com melanoma e apenas 8,8% dos dermatologistas o consideraram confiável; nenhum paciente preferiu o aplicativo sozinho.[4]

Esse estudo excluiu fototipos V e VI e concentrou-se em uma população de alto risco, de modo que não fornece uma estimativa direta para a população geral. Seu valor principal para esta comparação é mostrar que desempenho e aceitação podem se deteriorar quando a tarefa é composta por lesões pigmentadas difíceis e quando o resultado é interpretado como triagem de encaminhamento.

### Estudos históricos

O estudo de Thissen et al. avaliou a versão calibrada de uma abordagem de análise fractal e clássica de imagem em 108 lesões de avaliação, depois de calibrar o algoritmo com 233 lesões; no conjunto de avaliação, relatou 80% de sensibilidade e 78% de especificidade para condições pré-malignas ou malignas.[9] O estudo de Maier et al. avaliou uma versão inicial para lesões pigmentadas em 195 lesões, com 40 melanomas, e relatou 73% de sensibilidade e 83% de especificidade; dermatologistas obtiveram 88% e 97%, respectivamente.[10] Esses resultados documentam a evolução do produto, mas não devem ser tratados como validação da versão atual.

## Alegação comercial versus evidência clínica

A instrução de uso atual afirma sensibilidade superior a 90% para melanoma maligno, carcinoma espinocelular e carcinoma basocelular e especificidade de 89% “na população SkinVision”.[1] O comunicado comercial de 2025 também afirma que o serviço foi clinicamente validado, que passou por revisão de especialistas europeus e que apresentou desempenho consistente em casos-limite, dispositivos e condições de iluminação.[3] A página oficial de resposta ao estudo de Ghent afirma que atualizações do modelo foram implementadas desde o período de 2021–2023 e menciona validações recentes com sensibilidade em torno de 90%.[11]

Essas afirmações não são equivalentes aos resultados publicados em estudos prospectivos independentes. As fontes oficiais consultadas não fornecem, na mesma granularidade, tamanho amostral, composição de casos, intervalos de confiança, padrão de referência, taxa de falha de captura, distribuição de fototipos, versão exata do modelo e análise por dispositivo para a cifra “>90%/89%”. Por isso, o valor deve ser registrado como **alegação de desempenho da documentação do produto**, e não como substituto dos resultados independentes. A comparação mais defensável deve usar o fluxo completo, incluindo imagens recusadas e casos de uso doméstico, e não somente imagens aceitas pelo classificador.

## Comparação direta com o SkinCancerCADDermoIA

| Dimensão | SkinVision | SkinCancerCADDermoIA, conforme escopo informado |
| --- | --- | --- |
| Uso pretendido | Triagem OTC por leigos adultos; indica risco e orienta monitoramento ou consulta. Não diagnostica. | Protótipo de apoio à análise de lesões por dermatoscopia. O uso pretendido regulatório e a população-alvo ainda precisam ser formalizados. |
| Modalidade | Fotografia macroscópica de close-up em smartphone, com checagem de foco, detecção, nitidez e iluminação. | Dermatoscopia, que pode disponibilizar padrões subsuperficiais e estruturas que não aparecem na fotografia macroscópica. |
| Núcleo conhecido | Uma versão publicada foi descrita como CNN RD-174; a arquitetura atual completa não é pública. | ResNet-50, Vision Transformer, modelo híbrido e ensemble ponderado são componentes explicitamente previstos no protótipo. |
| Ensemble | Não divulgado publicamente. | Ensemble ponderado explícito; devem ser publicados pesos, método de ajuste e análise de calibração. |
| OOD | Não há descrição pública de detector OOD ou de rejeição por distribuição. “Quality check needed” é controle de aquisição/serviço, não prova de OOD. | Triagem OOD explícita. Deve ser validada com artefatos, lesões fora do domínio, dispositivos não vistos e casos de baixa qualidade. |
| Incerteza | Não há escore, intervalo ou decomposição de incerteza divulgada. | Incerteza explícita. Deve ser calibrada e ligada a uma ação segura, como revisão humana ou abstention. |
| Saídas | Baixo/alto risco, monitorar ou consultar profissional, checagem adicional, lembretes e relatório. Não fornece classe histopatológica. | A especificação final precisa declarar se haverá classe, risco, probabilidade calibrada, abstention e recomendação. Não se deve presumir uma saída clínica apenas por haver múltiplos modelos. |
| XAI | Não foram encontrados mapas de saliência, atenção visual explicável ou justificativas por caso. Revisão dermatológica é controle humano. | XAI declarada no escopo. Deve informar técnica, estabilidade, fidelidade e modo de apresentar a explicação sem sugerir causalidade clínica indevida. |
| Validação publicada | Estudos prospectivos com resultados variáveis; 2022: 86,9%/70,4%; 2026: 82,5%/76,8% em imagens capturadas com sucesso. | Não há, nesta nota, resultado clínico do protótipo. Ele precisa de validação independente com separação por paciente, conjunto externo e padrão de referência definido antes do teste. |
| Aquisição e falhas | Falhas de captura são relevantes: 16,6% em condições ideais no estudo de 2026 e desempenho muito pior quando o usuário captura a imagem. | A dermatoscopia pode padronizar a aquisição, mas introduz dependência de equipamento e operador. O protocolo deve contar imagens inválidas e abstentions no denominador. |
| Segurança operacional | Recomenda consulta em alto risco, possui checagens de qualidade e painel de dermatologistas para imagens de risco; ainda pode produzir falso negativo ou falso positivo. | OOD, incerteza, ensemble e XAI podem formar uma camada de segurança mais auditável, mas só têm valor após teste de impacto, calibração e revisão humana. |
| Estado regulatório | A empresa declara CE sob EU MDR classe IIa; disponibilidade nos EUA pendente de autorização FDA. | Deve ser tratado como protótipo de pesquisa até que exista documentação regulatória própria; não se deve transferir o estado regulatório do SkinVision. |

A principal diferença não é apenas “CNN versus modelos modernos”. O SkinVision otimiza um fluxo consumerizado de fotografia macroscópica, triagem e encaminhamento, com detalhes do modelo protegidos como proprietários. O SkinCancerCADDermoIA pretende controlar mais explicitamente a representação da imagem, a combinação de modelos e a incerteza. Isso cria uma oportunidade de auditabilidade, mas também aumenta a obrigação de demonstrar que cada camada melhora o fluxo clínico em vez de apenas melhorar uma métrica retrospectiva.

## Limitações que devem orientar a comparação

- O modelo atual, os dados de treinamento, os limiares e a política de atualização do SkinVision não são públicos; inferências sobre ResNet-50, ViT, híbrido, ensemble, OOD ou incerteza seriam especulativas.
- A fotografia macroscópica não deve ser comparada diretamente com dermatoscopia como se as duas modalidades observassem a mesma informação. Qualquer comparação entre os sistemas precisa definir modalidade, tarefa e padrão de referência.
- Sensibilidade e especificidade variaram substancialmente entre estudos, plataformas, tipos de lesão, padrão de referência e condições de captura. A cifra comercial “superior a 90%/89%” não substitui a análise de um estudo prospectivo independente.
- O fracasso de aquisição é parte do desempenho do produto. Excluir imagens recusadas superestima o resultado do classificador quando a pergunta é se o usuário consegue completar o caminho até uma orientação.
- Os estudos disponíveis têm limitações de espectro e representatividade, incluindo pacientes de ambulatório especializado, poucos melanomas em alguns conjuntos, exclusão de fototipos escuros em estudos importantes e fotografias realizadas por pesquisadores treinados.
- A sobre-detecção pode aumentar encaminhamentos, ansiedade e procedimentos desnecessários; o falso negativo pode atrasar a consulta. Uma avaliação adequada deve medir consequências do limiar, não somente AUROC.
- A ausência de XAI, OOD e incerteza divulgadas impede afirmar que o SkinVision oferece essas salvaguardas. No protótipo, a mera presença nominal desses módulos também não prova segurança sem avaliação de calibração, abstention e utilidade clínica.
- Os resultados do SkinVision não são uma validação do SkinCancerCADDermoIA. O protótipo deve ser testado de forma independente, sem reutilizar cifras do produto comercial como evidência de desempenho próprio.

## Estado atual para registro no capítulo do sistema

Para o registro do sistema, o SkinVision deve ser descrito como **dispositivo móvel comercial de triagem por fotografia macroscópica, CE MDR classe IIa segundo a empresa, com modelo proprietário e documentação pública limitada da arquitetura, que produz indicação de risco e encaminhamento, não diagnóstico**. A evidência clínica disponível inclui validações prospectivas independentes, porém com desempenho variável, falhas importantes de aquisição, dependência de dispositivo e limitações de população e fototipo. A empresa afirma atualizações de modelo e validações recentes, mas os detalhes necessários para reproduzir ou auditar essas alegações não estão disponíveis nas fontes oficiais consultadas.

Para fins de comparação, o SkinCancerCADDermoIA diferencia-se por usar dermatoscopia e por declarar uma arquitetura composta de ResNet-50, Vision Transformer, modelo híbrido, ensemble ponderado, triagem OOD, incerteza e XAI. Essa diferença é uma hipótese de projeto, não uma superioridade clínica demonstrada. A próxima validação do protótipo deve incluir, no mínimo, desempenho por classe e por fototipo, calibração, taxa de abstention, falha de aquisição, subgrupos por dispositivo e localização, avaliação externa, comparação com dermatologistas e análise de consequências dos falsos positivos e negativos.

## Referências

[1]: https://content.skinvision.com/website/en/instructions-for-use-6-0-20.pdf "SkinVision Service 6.0 Instructions for Use, revision 1.8, 1 June 2026"

[2]: https://www.skinvision.com/en-us "SkinVision official product page and US availability notice"

[3]: https://www.skinvision.com/press-release/skinvision-earns-europes-top-medical-certification-for-ai-powered-skin-cancer-detection "SkinVision Earns Europe’s Top Medical Certification for AI-Powered Skin Cancer Detection"

[4]: https://pmc.ncbi.nlm.nih.gov/articles/PMC9367531/ "Over-Detection of Melanoma-Suspect Lesions by a CE-Certified Smartphone App: Performance in Comparison to Dermatologists, 2D and 3D Convolutional Neural Networks in a Prospective Data Set of 1204 Pigmented Skin Lesions Involving Patients’ Perception"

[5]: https://doi.org/10.1159/000520474 "Validation of a Market-Approved Artificial Intelligence Mobile Health App for Skin Cancer Screening: A Prospective Multicenter Diagnostic Accuracy Study"

[6]: https://derma.jmir.org/2019/1/e13376 "Development of Smartphone Apps for Skin Cancer Risk Assessment: Progress and Promise"

[7]: https://karger.com/drm/article/238/4/649/828305/Validation-of-a-Market-Approved-Artificial "Sangers et al. study discussion, limitations, funding and conflict-of-interest statement"

[8]: https://pubmed.ncbi.nlm.nih.gov/41701029/ "Artificial intelligence-based smartphone application for skin cancer detection: a prospective diagnostic accuracy study"

[9]: https://pubmed.ncbi.nlm.nih.gov/28562195/ "mHealth App for Risk Assessment of Pigmented and Nonpigmented Skin Lesions—A Study on Sensitivity and Specificity in Detecting Malignancy"

[10]: https://pubmed.ncbi.nlm.nih.gov/25087492/ "Accuracy of a smartphone application using fractal image analysis of pigmented moles compared to clinical diagnosis and histological result"

[11]: https://www.skinvision.com/news/response-to-media-coverage-about-the-study-by-uz-gent "SkinVision response to media coverage about the study by UZ Gent"

> **Nota metodológica sobre a evidência.** As cifras de desempenho são reproduzidas com o padrão de referência e a população descritos em cada publicação. A instrução de uso e os comunicados da empresa foram usados para modalidade, uso pretendido, estado regulatório, limitações operacionais e alegações comerciais; não foram tratados como substitutos de validação clínica independente.
